__author__ = 'Yas'
__author__ = 'Yas'
import numpy as np
from sklearn import hmm
import unittest
from Tkinter import *

def f(marks,prb):
    if len(marks)!=2:
      print "Error"
    else:
      states = ["A", "B","C", "F"]
      n_states = len(states)
      observations = ["sub1-A", "sub1-B", "sub1-C","sub1-D","sub2-A", "sub2-B", "sub2-C","sub2-D"]
      #observations = ["OOP-A", "OOP-B", "OOP-C","OOP-D"]
      n_observations = len(observations)
      start_probability = np.array([0.25, 0.25,0.25, 0.25])
      transition_probability = np.array([[0.4, 0.3,0.2, 0.1],[0.3, 0.4,0.2, 0.1],[0.1, 0.3,0.4, 0.2],[0.1, 0.2,0.3, 0.4]])
      #emission_probability = np.array([[0.2, 0.1,0.1, 0.1,0.2, 0.1,0.1, 0.1],[0.2, 0.1,0.1, 0.1,0.2, 0.1,0.1, 0.1],[0.2, 0.1,0.1, 0.1,0.2, 0.1,0.1, 0.1],[0.2, 0.1,0.1, 0.1,0.2, 0.1,0.1, 0.1]])
      #emission_probability = np.array([[0.4, 0.2,0.2, 0.2],[0.4, 0.2,0.2, 0.2],[0.4, 0.2,0.2, 0.2],[0.4, 0.2,0.2, 0.2]])
      emission_probability = np.array(prb)
      model = hmm.MultinomialHMM(n_components=n_states)
      model._set_startprob(start_probability)
      model._set_transmat(transition_probability)
      model._set_emissionprob(emission_probability)
      bob_says = marks
      logprob, pred = model.decode(bob_says, algorithm="viterbi")

      print "Previous Exam Result:", ", ".join(map(lambda x: observations[x], bob_says))
      print "Predicted Software Engineering Result:", ", ".join(map(lambda x: states[x], pred))
      if (pred[0]!=3)&(pred[1]!=3)&(pred[0]!=2)&(pred[1]!=2):
            con="Student Approved"
      else:con="Not Sufficient Requirenment"
    window = Tk()
    window.configure(background='#8A002E')
    window.title('Margov Prediction')
    window.geometry('350x180') # Size 200, 200
    frame = Frame(window,background='#8A002E')
    frame.pack()
    Label(frame, background='#8A002E',font=("Helvetica", 14),foreground="white",text="Student's predicted success:").grid(row=0, column=0)
    Label(frame, background='#8A002E',font=("Helvetica", 14),foreground="white",text=", ".join(map(lambda x: states[x], pred))).grid(row=0, column=1)
    Label(frame,background='#8A002E', text=con,fg="red",font=("Helvetica", 24)).grid(row=1, column=0)
    Button(frame, text='Quit', command=window.quit).grid(row=2, column=2, sticky=W, pady=4)
    return 0

#unit testing
#class MyTest(unittest.TestCase):
    #def test(self):
       # self.assertEqual(f([0]), 0)

