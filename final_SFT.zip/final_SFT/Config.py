__author__ = 'Yas'
from Tkinter import *
import MySQLdb
from ttk import Frame, Button, Style
from Tkinter import Tk
import base64
import tkMessageBox as box
from PIL import Image, ImageTk
import os
from Crypto.Cipher import AES
from Crypto import Random

class Example():
    def onError(self):
        box.showerror("Error", "Could not Upadate")

    def onQuest(self):
        box.askquestion("Question", "Are you sure to quit?")

    def onInfo(self):
        box.showinfo("Information", "Upadate Sucessfully")


master = Tk()
master.configure(background='#8A002E')
img = ImageTk.PhotoImage(Image.open("logo4.jpg"))
imglabel = Label(master, image=img).grid(row=0, column=3)

master.wm_title("System Configuration")
Label(master,background='#8A002E',foreground="white", text="Enter System UserName").grid(row=1)
Label(master,background='#8A002E',foreground="white", text="Enter System Password:").grid(row=2)
Label(master,background='#8A002E',foreground="white", text="Edit DB UserName").grid(row=3)
Label(master,background='#8A002E',foreground="white", text="Edit DB Passwor:").grid(row=4)
Label(master,background='#8A002E',foreground="white", text="No of Related Subjects:").grid(row=5)
e1 = Entry(master)
e2 = Entry(master)
e3 = Entry(master)
e4 = Entry(master)
e5 = Entry(master)

e1.grid(row=1, column=1)
e2.grid(row=2, column=1)
e3.grid(row=3, column=1)
e4.grid(row=4, column=1)
e5.grid(row=5, column=1)
#set username from file-------------------
def setUserUsername(user,f):
   f.write(base64.b64encode(user))
   f.write("\n")

#set pass from file-------------------
def setUserPassword(pas,f):
   f.write(base64.b64encode(pas))
   f.write("\n")
#set username from file-------------------
def setSubNo(SNo,f):
   f.write(SNo)
   f.write("\n")

#set username from file-------------------
def setDBUsername(user,f):
   f.write(user)
   f.write("\n")

#set pass from file-------------------
def setDBPassword(pas,f):
   f.write(pas)
   f.write("\n")
#setDB
def SetDB(userDB,pasDB,userName,PassWd,SNo):
    name="Lecturer"
    db = MySQLdb.connect("localhost",userDB,pasDB,"marks" )
    cursor = db.cursor()
    key="sri"
    Er=""

    sql="INSERT INTO users(Name,UserName,PassWord,SNo) VALUES('%s','%s',AES_ENCRYPT('%s','%s'),'%d')"% (name,userName,key,PassWd,int(SNo));
    try:
       # Execute the SQL command
       cursor.execute(sql)
       # Commit your changes in the database
       db.commit()
    except:
       Er="not null"
       #Rollback in case there is any error
       db.rollback()
       print "Error: unable to Inser data"
       Example().onError()
    if Er=="null":
     Example().onInfo()
    # disconnect from server
    db.close()

def Fun():
    UserNM = e1.get()
    PassWD = e2.get()
    DBNM = e3.get()
    DBWD = e4.get()
    SNo=e5.get()
    f = open('Config.txt',"w")
    setUserUsername(UserNM,f)
    setUserPassword(PassWD,f)
    setDBUsername(DBNM,f)
    setDBPassword(DBWD,f)
    setSubNo(SNo,f)
    SetDB(DBNM,DBWD,UserNM,PassWD,SNo)
    if f==NONE:
        Example().onError()
    else:
        Example().onInfo()
        master.quit()
    f.close()

def HelpCon():
    os.system('python HelpConfig.py')
def Back():
   import os
   master.withdraw()
   os.system('python win_HomeConfig.py')

Button(master, text='Back', command=Back).grid(row=7, column=0, sticky=W, pady=4)
Button(master, text='HELP', command=HelpCon).grid(row=7, column=1, sticky=W, pady=4)
Button(master, text='Quit', command=master.quit).grid(row=7, column=2, sticky=W, pady=4)
Button(master, text='Submit', command=Fun).grid(row=7, column=3, sticky=W, pady=4)
mainloop( )
